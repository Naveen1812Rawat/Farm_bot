#!/usr/bin/env python

import rospy
import sys, select, termios, tty
from sensor_msgs.msg import JointState
from std_msgs.msg import Header
from std_msgs.msg import Float64
from std_msgs.msg import Float64MultiArray

global array1,array2,kp,ki,kd,sum1,sum2,sum3,sum4
[sum1,sum2,sum3,sum4]=[0,0,0,0]
array2=[sum1,sum2,sum3,sum4]
array1=[sum1,sum2,sum3,sum4]
kp=0.2
ki=0.001
kd=0.25


def getKey(key_timeout):
	settings = termios.tcgetattr(sys.stdin)
	tty.setraw(sys.stdin.fileno())
	rlist, _, _ = select.select([sys.stdin], [], [], key_timeout)
	if rlist:
		key = sys.stdin.read(1)
	else:
		key = ''
	termios.tcsetattr(sys.stdin, termios.TCSADRAIN, settings)
	return key
	
def velocity():
	g=getKey(10)
	if(g=='1'):
		return 0.0
	elif(g=='2'):
		return 0.05
	elif(g=='3'):
		return 0.1

def c(joint):
	global array1
	[wheellf,wheellr,wheelrf,wheelrr]=joint.velocity
	error1=awheellf-wheellf
	error2=awheellr-wheellr
	error3=awheelrf-wheelrf
	error4=awheelrr-wheelrr
	error=[error1,error2,error3,error4]
	p1=error1*kp
	p2=error2*kp
	p3=error3*kp
	p4=error4*kp
	array2[0]+=error1
	array2[1]+=error2
	array2[2]+=error3
	array2[3]+=error4
	i1=array2[0]*ki
	i2=array2[1]*ki
	i3=array2[2]*ki
	i4=array2[3]*ki
	d1=-(array1[0]-error1)*kd
	d2=-(array1[1]-error2)*kd
	d3=-(array1[2]-error3)*kd
	d4=-(array1[3]-error4)*kd
	array1=[error1,error2,error3,error4]
	
	pid1=p1+i1+d1
	pid2=p2+i2+d2
	pid3=p3+i3+d3
	pid4=p4+i4+d4
	
	print(error)
	
	multiarray1.data=[pid1,pid2]
	multiarray2.data=[pid3,pid4]
	pub1.publish(multiarray1)
	pub2.publish(multiarray2)
	pub3.publish(wheellf)
	
if __name__ == "__main__":
	while (1):
		k=getKey(10)
		if(k=='a'):
			awheellf=velocity()
		elif(k=='d'):
			awheelrf=velocity()
		elif(k=='b'):
			break
	awheellr=awheellf
	awheelrr=awheelrf
	rospy.init_node('pid_control')
	rospy.Rate(2)
	pub1=rospy.Publisher('MYROBOT/l_con_position_controller/command',Float64MultiArray,queue_size=10)
	pub2=rospy.Publisher('MYROBOT/r_con_position_controller/command',Float64MultiArray,queue_size=10)
	pub3=rospy.Publisher('MYROBOT/first_wheel_pid', Float64, queue_size=10)
	multiarray1= Float64MultiArray()
	multiarray2= Float64MultiArray()
	while(1):
		joint=JointState()
		sub = rospy.Subscriber('MYROBOT/joint_states',JointState,c)
