#!/usr/bin/env python

import rospy
import sys, select, termios, tty
from sensor_msgs.msg import JointState
from std_msgs.msg import Header
from std_msgs.msg import Float64
from std_msgs.msg import Float64MultiArray

global array1,array2,array3,array4,kp,ki,kd
array1=[0,0,0,0]
array2=[0,0,0,0]
array3=[0,0,0,0]
array4=[0,0,0,0]
kp=1
ki=0.5
kd=2

def getKey(key_timeout):
	settings = termios.tcgetattr(sys.stdin)
	tty.setraw(sys.stdin.fileno())
	rlist, _, _ = select.select([sys.stdin], [], [], key_timeout)
	if rlist:
		key = sys.stdin.read(1)
	else:
		key = ''
	termios.tcsetattr(sys.stdin, termios.TCSADRAIN, settings)
	return key
	
def velocity():
	if(g=='1'):
		return 0.0
	elif(g=='2'):
		return 0.05
	elif(g=='3'):
		return 0.1

def c(joint):
	[wheellf,wheellr,wheelrf,wheelrr]=joint.velocity
	error1=awheellf-wheellf
	error2=awheellr-wheellr
	error3=awheelrf-wheelrf
	error4=awheelrr-wheelrr
	error=[error1,error2,error3,error4]
	p1=error1*kp
	p2=error2*kp
	p3=error3*kp
	p4=error4*kp
	array1.pop(0)
	array1.append(error1)
	array1[3]=error1
	i1=sum(array1)*ki
	array2.pop(0)
	array2.append(error2)
	array2[3]=error2
	i2=sum(array2)*ki
	array3.pop(0)
	array3.append(error3)
	array3[3]=error3
	i3=sum(array3)*ki
	array4.pop(0)
	array4.append(error4)
	array4[3]=error4
	i4=sum(array4)*ki
	d1=(array1[2]-array1[3])*kd
	d2=(array2[2]-array2[3])*kd
	d3=(array3[2]-array3[3])*kd
	d4=(array4[2]-array4[3])*kd
	
	pid1=p1+i1+d1
	pid2=p2+i2+d2
	pid3=p3+i3+d3
	pid4=p4+i4+d4
	
	multiarray1.data=[pid1,pid2]
	multiarray2.data=[pid3,pid4]
	pub1.publish(multiarray1)
	pub2.publish(multiarray2)
	print(error)
	
if __name__ == "__main__":
	while (1):
		k=getKey(10)
		if(k=='1'):
			awheellf=velocity()
		elif(k=='2'):
			awheellr=velocity()
		elif(k=='3'):
			awheelrf=velocity()
		elif(k=='4'):
			awheelrr=velocity()
		elif(k=='b'):
			break
	rospy.init_node('pid_control')
	rospy.Rate(2)
	pub1=rospy.Publisher('/fb_model/l_con_position_controller/command',Float64MultiArray,queue_size=10)
	pub2=rospy.Publisher('/fb_model/r_con_position_controller/command',Float64MultiArray,queue_size=10)
	multiarray1= Float64MultiArray()
	multiarray2= Float64MultiArray()
	while (1):
		joint=JointState()
		sub = rospy.Subscriber('/fb_model/joint_state',JointState,c)
