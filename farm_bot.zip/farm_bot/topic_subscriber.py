#!/usr/bin/env python
import rospy
from std_msgs.msg import Int32
from sensor_msgs.msg import JointState
def callback(msg):
	print (msg.effort)
rospy.init_node('topic_subscriber')
sub = rospy.Subscriber('/MYROBOT/joint_states',JointState, callback)
rospy.spin()
