#!/usr/bin/env python3

import sys, select, termios, tty
import rospy
from std_msgs.msg import Float64MultiArray
from sensor_msgs.msg import JointState
global Kp,Kd,Ki
kp = 0.1
ki = 0.01
kd = 0.01
		
def getKey(key_timeout):
	settings = termios.tcgetattr(sys.stdin)
	tty.setraw(sys.stdin.fileno())
	rlist, _, _ = select.select([sys.stdin], [], [], key_timeout)
	if rlist:
		key = sys.stdin.read(1)
	else:
		key = ''
	termios.tcsetattr(sys.stdin, termios.TCSADRAIN, settings)
	return key
	
def callback(joint,k):
	[wheel_l1,wheel_l2,wheel_r1,wheel_r2] = Joint.velocity
	if (k=='w'):
		error_l1 = 0.05 - wheel_l1
		error_l2 = 0.05 - wheel_l2
		error_r1 = 0.05 - wheel_r1
		error_r2 = 0.05 - wheel_r2
	elif(k=='s'):
		error_l1 = -0.05 - wheel_l1
		error_l2 = -0.05 - wheel_l2
		error_r1 = -0.05 - wheel_r1
		error_r2 = -0.05 - wheel_r2
	elif(k=='a'):
		error_l1 = 0.0 - wheel_l1
		error_l2 = 0.0 - wheel_l2
		error_r1 = 0.05 - wheel_r1
		error_r2 = 0.05 - wheel_r2
	elif(k=='d'):
		error_l1 = 0.05 - wheel_l1
		error_l2 = 0.05 - wheel_l2
		error_r1 = 0.0 - wheel_r1
		error_r2 = 0.0 - wheel_r2
	error=[error_l1,error_l2,error_r1,error_r2]
	p1=error_l1*kp
	p2=error_l2*kp
	p3=error_r1*kp
	p4=error_r2*kp
	array2[0]+=error_l1
	array2[1]+=error_l2
	array2[2]+=error_r1
	array2[3]+=error_r2
	i1=array2[0]*ki
	i2=array2[1]*ki
	i3=array2[2]*ki
	i4=array2[3]*ki
	d1=-(array1[0]-error_l1)*kd
	d2=-(array1[1]-error_l2)*kd
	d3=-(array1[2]-error_r1)*kd
	d4=-(array1[3]-error_r2)*kd
	array1=[error_l1,error_l2,error_r1,error_r2]
	
	pid1=p1+i1+d1
	pid2=p2+i2+d2
	pid3=p3+i3+d3
	pid4=p4+i4+d4
	print(error)
	
	multiarray1.data=[pid1,pid2]
	multiarray2.data=[pid3,pid4]
	publ.publish(multiarray1)
	pubr.publish(multiarray2)
	pub3.publish(wheellf)
	   

if __name__ == '__main__':
	rospy.init_node('feedback')
	publ=rospy.Publisher('MYROBOT/l_con_position_controller/command', Float64MultiArray,queue_size=10)
	pubr=rospy.Publisher('MYROBOT/r_con_position_controller/command', Float64MultiArray,queue_size=10)
	joint = JointState()
	r=rospy.Rate(2)
	while (1):
		k = getKey(10)
		if(k=='w'):
			[wheell1,wheell2,wheelr1,wheelr2] = [0.05,0.05,0.05,0.05]
			wheels=Float64MultiArray()
			wheels.data=[wheell1,wheell2,wheelr1,wheelr2]
		elif(k=='s'):
			[wheell1,wheell2,wheelr1,wheelr2] = [-0.05,-0.05,-0.05,-0.05]
			wheels=Float64MultiArray()
			wheels.data=[wheell1,wheell2,wheelr1,wheelr2]
		elif(k=='a'):
			[wheell1,wheell2,wheelr1,wheelr2] = [0.0,0.0,0.05,0.05]
			wheels=Float64MultiArray()
			wheels.data=[wheell1,wheell2,wheelr1,wheelr2]
		elif(k=='d'):
			[wheell1,wheell2,wheelr1,wheelr2] = [0.05,0.05,0.0,0.0]
			wheels=Float64MultiArray()
			wheels.data=[wheell1,wheell2,wheelr1,wheelr2]
		if(k=='b'):
			break
	sub = rospy.Subscriber('/MYROBOT/joint_states',JointState,callback(joint,k))
	r.sleep
			
			
	
	
	
	



