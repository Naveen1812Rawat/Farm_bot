#!/usr/bin/env python3

import rospy
from sensor_msgs.msg import JointState
from std_msgs.msg import Float64
from std_msgs.msg import Float64MultiArray

global error_prev,error_sum,kp,ki,kd,p,i,d,pid
error_sum=[0.0,0.0,0.0,0.0]
error_prev=[0.0,0.0,0.0,0.0]
error=[0.0,0.0,0.0,0.0]
p=[0.0,0.0,0.0,0.0]
i=[0.0,0.0,0.0,0.0]
d=[0.0,0.0,0.0,0.0]
pid=[0.0,0.0,0.0,0.0]
kp=0.001
ki=0.0001
kd=0.0
rospy.init_node('node')
pub1=rospy.Publisher('/MYROBOT/l_con_position_controller/command',Float64MultiArray,queue_size=10)
pub2=rospy.Publisher('/MYROBOT/r_con_position_controller/command',Float64MultiArray,queue_size=10)
pub3=rospy.Publisher('/MYROBOT/first_wheel_pid', Float64, queue_size=10)
multiarray1= Float64MultiArray()
multiarray2= Float64MultiArray()
joint=JointState()

def c(joint):
	global error_prev,set_velocity,p,i,d,pid,error_sum
	current_velocity=joint.velocity
	print(error)
	for j in range(4):
		error[j]=set_velocity[j]-current_velocity[j]
		p[j]=error[j]*kp
		error_sum[j]+=error[j]*0.05
		i[j]=error_sum[j]*ki
		d[j]=(error[j]-error_prev[j])*kd
		pid[j]=p[j]+i[j]+d[j]
		print(pid)
		
	error_prev=error
	multiarray1.data=[pid[0],pid[1]]
	multiarray2.data=[pid[2],pid[3]]
	pub1.publish(multiarray1)
	pub2.publish(multiarray2)
	pub3.publish(current_velocity[0])

def callback(setwheel):
	global set_velocity,wheellf
	[setwheellf,setwheelrf]=setwheel.data
	setwheellr=setwheellf
	setwheelrr=setwheelrf
	set_velocity=[setwheellf,setwheellr,setwheelrf,setwheelrr]
	sub = rospy.Subscriber('/MYROBOT/joint_states',JointState,c)
	rospy.spin()
	
	
if __name__ == "__main__":
	sub=rospy.Subscriber('set_velocity', Float64MultiArray, callback)
	rospy.spin()
