#!/usr/bin/env python3

import numpy as np
import sys, select, termios, tty
import rospy
from std_msgs.msg import Float64MultiArray
from sensor_msgs.msg import JointState
from geometry_msgs.msg import Twist
global kp,kpi,kd
kp = 0.01
ki = 0.01
kd = 0.01
global set_velocity, current_velocity,error, prev_error
set_velocity = [0,0,0,0]
current_velocity = [0,0,0,0]
error = [0,0,0,0]
prev_error =[0,0,0,0]
p = [0,0,0,0]
i = [0,0,0,0]
d = [0,0,0,0]
finalvalue = [0,0,0,0]
sum_error = [0,0,0,0]
wheels_l = Float64MultiArray()
wheels_r = Float64MultiArray()
def callback1(joint):
	global set_velocity, current_velocity
	global wheels_l, wheels_r, prev_error, p, i, d, finalvalue, sum_error, error
	current_velocity = joint.velocity
	for j in range(4):
		error[j] = set_velocity[j] - current_velocity[j]
		p[j] = error[j]*kp
		sum_error[j] += error[j]
		d[j] = (error[j] - prev_error[j])*kd
		i[j] = sum_error[j]*ki
		finalvalue[j] = p[j] + i[j] + d[j]
		print(finalvalue)
	prev_error = error
	wheels_l.data = [finalvalue[0],finalvalue[1]]
	wheels_r.data = [finalvalue[2],finalvalue[3]]
	pubr.publish(wheels_r)
	publ.publish(wheels_l)

def callback(wheel):
#	global set_velocity
	[set_wheel_lf,set_wheel_rf] = wheel.data
	set_wheel_rr = set_wheel_rf
	set_wheel_lr = set_wheel_lf
	set_velocity = [set_wheel_lf,set_wheel_lr,set_wheel_rf,set_wheel_rr]
				

if __name__ == "__main__":
	rospy.init_node("Teleop_feedback")
	rospy.Rate(2)
	joint = JointState() 
	pubr = rospy.Publisher('/MYROBOT/r_con_position_controller/command',Float64MultiArray,queue_size = 50)
	publ = rospy.Publisher('/MYROBOT/l_con_position_controller/command',Float64MultiArray,queue_size = 50)
	sub1 = rospy.Subscriber("set_velocity",Float64MultiArray,callback)
	sub2 = rospy.Subscriber("MYROBOT/joint_states",JointState,callback1)
	rospy.spin()
	
	
