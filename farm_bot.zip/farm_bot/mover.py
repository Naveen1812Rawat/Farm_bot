#!/usr/bin/env python3

import sys, select, termios, tty
import rospy
from std_msgs.msg import Float64MultiArray
global wheell1,wheelr1,wheell,wheelr
[wheell1,wheell2,wheelr1,wheelr2]=[0,0,0,0]

def getKey(key_timeout):
	settings = termios.tcgetattr(sys.stdin)
	tty.setraw(sys.stdin.fileno())
	rlist, _, _ = select.select([sys.stdin], [], [], key_timeout)
	if rlist:
		key = sys.stdin.read(1)
	else:
		key = ''
	termios.tcsetattr(sys.stdin, termios.TCSADRAIN, settings)
	return key
	
if __name__ ==  '__main__':
	rospy.init_node('gazebo_key')
	pub=rospy.Publisher('MYROBOT/l_con_position_controller/command', Float64MultiArray,queue_size=10)
#	pubr=rospy.Publisher('MYROBOT/r_con_position_controller/command', Float64MultiArray,queue_size=10)
	r=rospy.Rate(2)

	while (1):
		k=getKey(10)
		if(k=='w'):
			[wheell1,wheell2,wheelr1,wheelr2] = [0.1,0.1,0.1,0.1]
			wheels=Float64MultiArray()
			wheels.data=[wheell1,wheell2,wheelr1,wheelr2]
			pub.publish(wheels)
		elif(k=='s'):
			[wheell1,wheell2,wheelr1,wheelr2] = [-0.1,-0.1,-0.1,-0.1]
			wheels=Float64MultiArray()
			wheels.data=[wheell1,wheell2,wheelr1,wheelr2]
			pub.publish(wheels)
		elif(k=='a'):
			[wheell1,wheell2,wheelr1,wheelr2] = [0.0,0.0,0.1,0.1]
			wheels=Float64MultiArray()
			wheels.data=[wheell1,wheell2,wheelr1,wheelr2]
			pub.publish(wheels)
		elif(k=='d'):
			[wheell1,wheell2,wheelr1,wheelr2] = [0.1,0.1,0.0,0.0]
			wheels=Float64MultiArray()
			wheels.data=[wheell1,wheell2,wheelr1,wheelr2]
			pub.publish(wheels)
		elif(k=='b'):
			break
	r.sleep
